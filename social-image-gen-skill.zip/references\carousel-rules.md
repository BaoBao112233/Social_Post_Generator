# Carousel Generation Rules

## Core Principle

A carousel is a **single visual system**, not a collection of independent images. Every slide must feel like it belongs to the same post when swiped through.

## What Must Stay Constant Across All Slides

| Element | Rule |
|---------|------|
| Background color | Exact same hex code — no drift, no approximation |
| Lighting direction | Upper-left (10-11 o'clock), same softness |
| Shadow style | Same feathered shadow, same direction |
| Color temperature | Warm or cool — identical across set |
| Camera lens feel | Same focal length feel (85-100mm) |
| Aspect ratio | Same ratio for every slide — never mix |
| Negative prompt | Identical prohibitions on every slide |
| Master Prompt | Same verbatim copy on every prompt |

## What Can Vary Between Slides

| Element | Allowed variation |
|---------|------------------|
| Layout pattern | A, B, C, or D — can differ per slide |
| Product angle | Different rotation/tilt per slide |
| Product positioning | Centered, left, right — can shift |
| Composition type | Close-up vs. full product vs. group |
| Action elements | Static on one slide, texture/pour on another |
| Negative space | More or less — for different text overlay needs |
| Product count | Feature one product or several per slide |

## Narrative Arc Patterns

### Pattern 1: Product Journey
1. Hero shot (full product, clean)
2. Close-up detail (texture, label, ingredients)
3. Product in action (application, pour, texture reveal)
4. Result/benefit shot (aspirational final frame)

### Pattern 2: Collection Showcase
1. Hero single (lead product)
2. Supporting products (group arrangement)
3. Full collection (all products together)
4. Signature piece (close-up of hero again)

### Pattern 3: Education Flow
1. Problem/hook visual (dramatic, attention-getting)
2. Solution reveal (product hero shot)
3. How it works (product in action, ingredients visible)
4. Proof/result (clean, confident final frame)

### Pattern 4: Simple Repetition
1-N. Same product from different angles/layouts — each slide adds a new perspective while maintaining unity

## Prompt Template for Carousel Slides

Each slide prompt must include this consistency anchor block:

```
CAROUSEL CONSISTENCY NOTE: 
This is slide [N] of [TOTAL] in a coordinated carousel post.
Visual anchors for this set:
- Background: [exact hex code]
- Lighting: Soft diffused studio light from upper-left
- Color mood: [warm neutral / cool premium / etc.]
- Camera: 85-100mm feel, moderate DOF
All slides must maintain exact visual continuity.
```

## Execution Strategy

1. **Plan all slides first** — determine the narrative arc, layout per slide, and key visual elements before generating anything
2. **Generate sequentially** — one slide at a time, one MCP call per slide
3. **Verify after each slide** — check that the generated image matches the established visual direction
4. **Regenerate if needed** — if a slide drifts from the set's look, regenerate before proceeding
5. **Use `thinking_level: high`** — carousel consistency benefits from deeper model reasoning
6. **Present as a set** — show all slides together so the user can evaluate cohesion

## Common Carousel Pitfalls

| Problem | Prevention |
|---------|-----------|
| Color drift between slides | Specify exact hex codes in every prompt, not descriptive color names |
| Inconsistent product scale | Specify frame height percentage in every prompt |
| Mixed visual styles | Use identical Master Prompt; only vary Layout layer |
| One slide feels "off" | Regenerate the outlier, don't adjust the others to match it |
| Too much variation | When in doubt, keep slides more similar rather than more different |
| Too little variation | Each slide should have a clear purpose — don't just repeat the same image |
