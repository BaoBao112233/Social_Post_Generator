---
name: social-image-gen
description: Generate brand-consistent social media images from caption content and product photos. Use when the user pastes a social post caption and uploads product image(s) and wants to generate marketing-ready visuals. Supports single images and carousel sets.
---

# Social Image Generator

Generate production-ready social media images from post content and product photos, grounded in project brand guidelines and visual references.

## Trigger

Activate this skill when the user:
- Pastes social caption / post content AND uploads or references product image(s)
- Asks to generate a social post image from content they provide
- Requests a carousel image set for a social post

## Expected Inputs

| Input | Required | Description |
|-------|----------|-------------|
| Caption / post content | Yes | Pasted text — the social post copy to visualize |
| Product image(s) | Yes | Uploaded file(s) or path(s) to product photos |
| Image count | No | Number of images to generate (default: 1) |
| Carousel flag | No | Whether to generate a coordinated multi-slide set |
| Aspect ratio | No | `4:5` or `1:1` (default: `4:5` for feed posts) |
| Additional instructions | No | Style notes, platform, layout preference, etc. |

---

## Workflow

### Step 1: Analyze the Content

Read the pasted caption / post content carefully. Extract:

1. **Product identification** — which product(s) are featured
2. **Post objective** — launch, education, promotion, storytelling, conversion
3. **Emotional tone** — aspirational, clinical, playful, premium, urgent
4. **Key claims / benefits** — what the post emphasizes about the product
5. **Visual cues in the copy** — any words that suggest a visual direction (e.g., "glow", "repair", "transform", "layer")
6. **Platform** — infer from hashtag style, caption length, or ask if unclear

### Step 2: Inspect the Product Image(s)

Examine every uploaded product image. Identify:

- Product shape, size, proportions
- Packaging material and finish (matte, glossy, metallic, soft-touch)
- Label typography and layout
- Product line (Daily Care / Recovery / Elixir or equivalent)
- Color of the packaging itself
- Any distinguishing visual features

**Critical rule:** The uploaded product image is the source of truth. The generated image must preserve the product's appearance faithfully. Never let the AI model reinvent or distort the product.

### Step 3: Load Visual Guidelines

Read `brand/visual_guideline.md` from the project root. This is the **primary design authority**. Extract and apply:

- Color palette rules — match the product's line to the correct background/accent colors
- Lighting direction and shadow style
- Composition patterns (Layouts A/B/C/D)
- Camera angle and lens feel
- Material/texture expectations
- The **Master Prompt** (Section 8) — this must be prepended to every generation prompt
- The **Absolute Prohibitions** — hard constraints that must never be violated

### Step 4: Load Additional Brand Files (Conditional)

Only read these when directly relevant:

| File | When to load |
|------|-------------|
| `brand/brand_context.md` | When you need brand positioning, target audience, or core messaging to inform the visual concept |
| `brand/brand_voice.md` | When the file has content AND you need tone guidance beyond what the caption implies |
| `brand/product_catelog.md` | When you need ingredient details, product category, or full product specs to inform the visual |

Do NOT load these files by default for every generation. The visual guideline + caption + product image are usually sufficient.

### Step 5: Review Image References

Browse `skills/reference/image_reference/` to find reference images from the same product line as the target product. Use these to:

- Learn the established composition patterns for this product line
- Understand the expected color treatment and mood
- Calibrate your prompt to match proven visual styles
- **NOT to copy** — references inform direction, not dictate it

If no matching references exist, rely on the visual guideline alone.

### Step 6: Determine Creative Concept

Based on Steps 1-5, decide:

1. **Layout choice** — A (Hero Single), B (Dynamic Group), C (Product-in-Action), or D (Floating)
   - Default to **Layout A** if nothing in the content suggests otherwise
   - Use Layout B if multiple products are shown or the post is about a product set
   - Use Layout C if the caption emphasizes texture, ingredients, or "how it works"
   - Use Layout D if the tone is premium/dramatic or the post is aspirational

2. **Color direction** — based on product line mapping from visual guidelines

3. **Mood and atmosphere** — derived from caption tone and post objective

4. **Composition specifics** — product placement, angle, negative space allocation

Present the concept to the user briefly before generating. Example:
> **Concept:** Layout A (Hero Single) on Nude Beige background. Product centered, 65% frame height. Soft studio lighting. Warm minimal editorial feel. Aspect ratio 4:5.

### Step 7: Build the Image Generation Prompt(s)

Construct each prompt using this **three-layer structure**:

```
[LAYER 1 — MASTER PROMPT]
Copy the full Master Prompt from visual_guideline.md Section 8.
This sets the overall style, lighting, color mood, and prohibitions.

[LAYER 2 — LAYOUT PROMPT]
Use the matching layout template (A/B/C/D) from visual_guideline.md Section 8.
Adapt it to the specific product and post context.

[LAYER 3 — SPECIFICS]
- Exact product name
- Product line → color palette mapping
- Aspect ratio and dimensions
- Any special instructions from the user
- Caption-derived mood/concept adjustments
```

**Prompt rules:**
- Always prepend the Master Prompt
- Always reference the uploaded product image via `input_image_path_1` (and _2, _3 for multiple products)
- Include "Use the provided product photo exactly as reference — preserve label, shape, proportions, and material finish"
- Include the negative prompt: ban flowers, water splashes, bokeh, sparkles, lens flare, props, human hands, pure white backgrounds, keyword soup
- Specify exact aspect ratio
- Do NOT use quality keyword soup ("4k, ultra HD, best quality, masterpiece")

### Step 8: Generate Images via Nanobanana MCP

Call `mcp__nanobanana__generate_image` with these parameters:

| Parameter | Value |
|-----------|-------|
| `prompt` | The full constructed prompt (Master + Layout + Specifics) |
| `input_image_path_1` | Path to the uploaded/referenced product image |
| `input_image_path_2/3` | Additional product images if needed |
| `aspect_ratio` | User-specified or default (`4:5`) |
| `negative_prompt` | Brand prohibitions: "flowers, leaves, plants, water splashes, bokeh, sparkles, lens flare, colored gels, dramatic shadows, props, human hands, lifestyle context, pure white background, keyword soup, 4k, ultra HD, best quality, masterpiece" |
| `model_tier` | `nb2` for standard posts, `pro` for high-importance or complex compositions |
| `resolution` | `2k` for social posts |
| `thinking_level` | `medium` for single images, `high` for carousels or complex layouts |
| `n` | Number of images (max 4 per call) |
| `output_path` | `skills/reference/image_create/` |

**For single image requests:** One call with `n: 1`.

**For multiple (non-carousel) images:** One call with `n` set to requested count (max 4).

**For carousel requests:** See the Carousel Generation section below.

### Step 9: Present Output

Return to the user:

1. **The prompt(s) used** — formatted in a code block so they can reuse/modify
2. **The generated image(s)** — displayed inline
3. **Brief concept rationale** — 1-2 sentences explaining the creative direction chosen
4. If carousel: note the visual thread connecting the slides

---

## Carousel Generation

When the user requests a carousel (multi-slide set):

### Planning Phase

1. Determine the number of slides from the user's request
2. Plan the **narrative arc** across slides:
   - What does each slide emphasize?
   - How do slides progress? (e.g., product intro → ingredients → texture → result)
3. Assign a layout to each slide — variation is good, but keep it coherent

### Visual Consistency Rules

All slides in a carousel MUST share:

- **Same background color** — exact hex, no drift between slides
- **Same lighting setup** — direction, softness, shadow style
- **Same color temperature** — warm/cool tone must be identical
- **Same camera lens feel** — focal length and depth of field
- **Same negative prompt** — prohibitions apply uniformly

Allowed variations between slides:

- Layout pattern (e.g., slide 1 = Layout A, slide 2 = Layout C)
- Product angle or positioning
- Composition emphasis (close-up vs. full product)
- Action elements (static vs. in-use)
- Text overlay space allocation

### Prompt Construction for Carousels

Each slide gets its own prompt, but all prompts share:
- The **identical Master Prompt** header
- The **identical color palette** (background hex, accent hex)
- The **identical negative prompt**
- A **slide-specific Layer 2 + Layer 3** section

Add a consistency anchor to each carousel prompt:
```
CAROUSEL CONSISTENCY: This is slide [N] of [TOTAL]. All slides use [BACKGROUND COLOR] background, [LIGHTING DESCRIPTION], and [COLOR MOOD]. Maintain exact visual continuity with other slides in this set.
```

### Execution for Carousels

- Generate slides sequentially (one `generate_image` call per slide) to maintain maximum control over consistency
- After generating each slide, visually verify it matches the established direction before proceeding
- If a slide drifts from the set's visual language, regenerate it before moving on
- Use `thinking_level: high` for all carousel slides

---

## Aspect Ratio Rules

| Ratio | When to use | Dimensions |
|-------|-------------|------------|
| `4:5` | **Default for feed posts.** Instagram, Facebook feed. Best for product hero shots. | 1080x1350 |
| `1:1` | Square format. Threads, LinkedIn, versatile cross-platform. | 1080x1080 |

- If the user specifies a ratio, use it exactly
- If unspecified, default to `4:5`
- For carousels, apply the **same ratio to every slide** — never mix ratios in one set
- Pass the ratio via the `aspect_ratio` parameter in the MCP call

---

## Product Fidelity Rules

The uploaded product image is sacred. To preserve fidelity:

1. Always pass the product image via `input_image_path_1`
2. Include explicit prompt language: "Use the provided product photo as the EXACT product reference. Preserve label typography, packaging shape, proportions, material texture, and color accurately."
3. Never ask the model to generate, redesign, or reimagine the product
4. If the model distorts the product (warped labels, wrong proportions, invented text), flag it and regenerate with stronger fidelity language
5. For Layout C (Product-in-Action), the product body stays faithful — only the "action" elements (powder, serum drops, etc.) are generated

---

## Concept Auto-Detection Heuristics

Use these signals from the caption to infer visual direction:

| Caption Signal | Inferred Direction |
|---------------|-------------------|
| Product launch, "new", "introducing" | Layout A — clean hero shot, maximum product visibility |
| Ingredients list, "powered by", "contains" | Layout C — show texture/ingredients visually |
| "Complete routine", "set", multiple products mentioned | Layout B — dynamic group arrangement |
| "Premium", "luxury", "exclusive", "limited" | Layout D — floating/levitation, dramatic feel |
| "Before/after", "transformation" | Layout A or C — focus on the product as the agent of change |
| Promotional / discount | Layout A — clean, conversion-optimized |
| Educational / how-to | Layout C — product in action, texture visible |
| Brand story / heritage | Layout A or D — elevated, editorial |

When signals conflict, prioritize: user instruction > caption tone > post objective > default (Layout A).

---

## Quick Reference: MCP Call Template

```
Tool: mcp__nanobanana__generate_image

prompt: "[MASTER PROMPT]\n\n[LAYOUT PROMPT]\n\n[SPECIFICS]"
input_image_path_1: "[path to product image]"
aspect_ratio: "4:5"
negative_prompt: "flowers, leaves, plants, water splashes, bokeh, sparkles, lens flare, colored gels, dramatic shadows, props, human hands, lifestyle context, pure white #FFFFFF background"
model_tier: "nb2"
resolution: "2k"
thinking_level: "medium"
n: 1
output_path: "skills/reference/image_create/"
```

---

## Output Checklist

Before presenting results, verify:

- [ ] Product appearance matches the uploaded reference (shape, label, color, proportions)
- [ ] Background color matches the product line's palette from visual guidelines
- [ ] No prohibited elements (flowers, bokeh, sparkles, props, etc.)
- [ ] No AI-generated text on product packaging (unless original image text is preserved)
- [ ] Lighting is soft, diffused, from upper-left
- [ ] Aspect ratio matches specification
- [ ] For carousels: all slides share consistent color direction and visual language
- [ ] Prompt(s) are included in the response for user reference
