# Prompt Architecture Reference

This document explains the three-layer prompt structure used by the social-image-gen skill.

## Layer 1 — Master Prompt (Constant)

The Master Prompt is copied verbatim from `brand/visual_guideline.md` Section 8. It establishes:

- Photography style (Korean minimalist skincare editorial)
- Lighting setup (soft diffused, upper-left source)
- Background rules per product line
- Color mood (tone-on-tone, monochromatic warm neutral)
- Camera feel (85-100mm, moderate DOF)
- Product rendering expectations (physically real, accurate labels)
- Composition principles (generous negative space, 55-75% frame height)
- Absolute prohibitions (no flowers, bokeh, sparkles, props, etc.)

**This layer NEVER changes between prompts.** It is the brand's visual DNA.

## Layer 2 — Layout Prompt (Per-concept)

Selected from one of four layout templates in `visual_guideline.md` Section 8:

### Layout A — Hero Single
- 1 product, centered or slightly left
- 60-75% frame height
- Maximum negative space
- Best for: launches, hero shots, conversion posts

### Layout B — Dynamic Group
- Multiple products at varying angles (15-45 degrees)
- Diagonal or triangular composition
- Slight overlap for depth
- Best for: product sets, routine posts, collection features

### Layout C — Product-in-Action
- Product in "active" state (powder spilling, serum dripping)
- Shows texture/content visually
- Storytelling through product interaction
- Best for: education, ingredients focus, texture highlights

### Layout D — Floating / Levitation
- Products appear to float at different heights
- Slight low camera angle
- Extended shadows for depth
- Best for: premium/aspirational posts, dramatic reveals

## Layer 3 — Specifics (Per-image)

Unique to each generation call:

- **Product name** — exact name from the catalog
- **Product line** — determines which color palette to use
- **Color mapping** — specific hex codes for background and accents
- **Aspect ratio** — `4:5` or `1:1` as specified
- **Mood adjustments** — derived from caption analysis
- **Special instructions** — anything the user adds
- **Carousel anchoring** — slide number and consistency notes (if carousel)

## Assembly Order

```
[Full Master Prompt — verbatim from visual_guideline.md]

[Layout Prompt — adapted template for chosen layout]

[Specifics block — product, colors, ratio, mood, instructions]
```

## Negative Prompt (Always Included)

```
flowers, leaves, plants, water splashes, bokeh, sparkles, lens flare, 
colored gels, dramatic shadows, props, human hands, lifestyle context, 
pure white #FFFFFF background, keyword soup, 4k, ultra HD, best quality, masterpiece
```

This is passed via the `negative_prompt` parameter, NOT embedded in the main prompt.

## Product Image Anchoring

Every prompt must include explicit product fidelity language:

> "Use the provided product photo as the EXACT product reference. Preserve label typography, packaging shape, proportions, material texture, and color accurately. Do not generate, redesign, or reimagine the product."

The product image file is passed via `input_image_path_1` (and `_2`, `_3` for multi-product compositions).
